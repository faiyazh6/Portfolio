let groceryList = []; // the array of all grocery items 
let instructions = document.querySelectorAll("p"); // query selector for <p>
let buttons = document.querySelectorAll("button"); // query selector for <button> 

let addItem = (item) => {
    groceryList.push(item); // adds each item to the grocery list 
    displayList(); 
}

let removeItem = (index) => {
    groceryList.splice(index, 1); // param 1: position of item removed; param 2: how many items removed
    displayList(); 
}

function moveItem(index, direction) {
  const item = groceryList[index];
  removeItem(index); // utilizes removeItem(index) to remove an item 
  direction === "up" ? groceryList.splice(index - 1, 0, item) : groceryList.splice(index + 1, 0, item); 
  // if move up, then param 1: reduce idx by 1; param 2: remove 0 items; param 3: add the item
  // if move down, then param 1: increase idx by 1 
  displayList(); 
}

function displayList() {
  const listElement = document.getElementById("grocery-list");
  listElement.innerHTML = "";  

  for (let i = 0; i < groceryList.length; i++) {
    let itemElement = document.createElement("p"); // creating a <p> element for each element in the list
    itemElement.innerHTML = `${i + 1}: ${groceryList[i]}`;
    listElement.appendChild(itemElement); 
  }

  for (let j = 0; j < instructions.length; j++) {
      instructions[j].style.backgroundColor = "aqua"; 
  }

  for (let k = 0; k < buttons.length; k++) {
      buttons[k].style.backgroundColor = "lime"; 
  }
}

// user clicking the "add" button
document.getElementById("add-button").addEventListener("click", () => {
  const newItem = document.getElementById("new-item").value;
  addItem(newItem);
});

// user clicking the "remove" button
document.getElementById("remove-button").addEventListener("click", () => {
  const selectedIndex = document.getElementById("item-number").value;
  removeItem(selectedIndex);
});

// user clicking the "up" button
document.getElementById("up-button").addEventListener("click", () => {
  const selectedIndex = document.getElementById("item-number").value;
  moveItem(selectedIndex, "up");
});

// Handle the user clicking the "down" button
document.getElementById("down-button").addEventListener("click", () => {
    const selectedIndex = document.getElementById("item-number").value;
    moveItem(selectedIndex, "down"); 
});